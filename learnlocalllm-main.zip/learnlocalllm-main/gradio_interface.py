import os
import gradio as gr
from typing import List, Optional, Dict, Tuple
import tempfile
import shutil
from main import RAGSystem

class GradioRAGInterface:
    def __init__(self):
        """Initialize the RAG system and temporary directories."""
        self.temp_dir = tempfile.mkdtemp()
        self.upload_dir = os.path.join(self.temp_dir, "uploads")
        self.cache_dir = os.path.join(self.temp_dir, "cache")
        os.makedirs(self.upload_dir, exist_ok=True)
        os.makedirs(self.cache_dir, exist_ok=True)
        
        # Initialize RAG system
        self.rag = RAGSystem(
            cache_dir=self.cache_dir,
            embedding_model='all-mpnet-base-v2'
        )
        
        # Track processed files
        self.processed_files = set()

    def __del__(self):
        """Cleanup temporary directories on deletion."""
        try:
            shutil.rmtree(self.temp_dir)
        except:
            pass

    def process_file(self, file: gr.File) -> str:
        """
        Process a single uploaded file.
        
        Args:
            file (gr.File): Uploaded file object
            
        Returns:
            str: Status message
        """
        if file is None:
            return "No file uploaded"
            
        try:
            # Save file to upload directory
            filename = os.path.basename(file.name)
            filepath = os.path.join(self.upload_dir, filename)
            
            # Check if already processed
            if filepath in self.processed_files:
                return f"File {filename} was already processed"
            
            # Copy file to upload directory
            shutil.copy2(file.name, filepath)
            
            # Process the file
            self.rag.add_document(filepath)
            self.processed_files.add(filepath)
            
            return f"Successfully processed {filename}"
            
        except Exception as e:
            return f"Error processing file: {str(e)}"

    def process_directory(self, directory: str) -> str:
        """
        Process all files in a directory.
        
        Args:
            directory (str): Path to directory
            
        Returns:
            str: Status message
        """
        if not directory or not os.path.exists(directory):
            return "Invalid directory path"
            
        try:
            self.rag.add_documents(directory)
            return f"Successfully processed documents from {directory}"
        except Exception as e:
            return f"Error processing directory: {str(e)}"

    def update_config(
        self,
        chunk_size: int,
        chunk_overlap: int,
        index_type: str,
        context_strategy: str,
        max_context_length: int
    ) -> str:
        """
        Update RAG system configuration.
        
        Args:
            chunk_size (int): Size of text chunks
            chunk_overlap (int): Overlap between chunks
            index_type (str): Type of FAISS index
            context_strategy (str): Strategy for combining contexts
            max_context_length (int): Maximum context length
            
        Returns:
            str: Status message
        """
        try:
            # Create new RAG system with updated config
            self.rag = RAGSystem(
                cache_dir=self.cache_dir,
                chunk_size=chunk_size,
                chunk_overlap=chunk_overlap,
                index_type=index_type,
                context_strategy=context_strategy,
                max_context_length=max_context_length
            )
            
            # Reprocess any existing files
            if self.processed_files:
                for filepath in self.processed_files:
                    self.rag.add_document(filepath)
                    
            return "Configuration updated successfully"
        except Exception as e:
            return f"Error updating configuration: {str(e)}"

    def query_system(
        self,
        query: str,
        k: int = 5,
        include_metadata: bool = True
    ) -> Tuple[str, str]:
        """
        Query the RAG system.
        
        Args:
            query (str): Question to ask
            k (int): Number of contexts to retrieve
            include_metadata (bool): Whether to include metadata
            
        Returns:
            Tuple[str, str]: Tuple of (answer, sources)
        """
        if not self.rag.is_index_built:
            return "No documents have been processed yet", ""
            
        try:
            # Get response with metadata
            response = self.rag.query(query, k=k, include_metadata=True)
            
            # Extract answer and sources
            answer = response['answer']
            sources = "\n".join([
                f"- {source}" for source in response['metadata']['source_files']
            ])
            
            return answer, f"Sources:\n{sources}"
            
        except Exception as e:
            return f"Error processing query: {str(e)}", ""

def create_interface() -> gr.Blocks:
    """Create and configure the Gradio interface."""
    interface = GradioRAGInterface()
    
    with gr.Blocks(title="RAG System Interface") as app:
        gr.Markdown("# Retrieval-Augmented Generation (RAG) System")
        
        with gr.Tabs():
            # Document Upload Tab
            with gr.Tab("Upload Documents"):
                with gr.Row():
                    with gr.Column():
                        file_input = gr.File(
                            label="Upload PDF/DOCX File",
                            file_types=[".pdf", ".docx"]
                        )
                        upload_button = gr.Button("Process File")
                    with gr.Column():
                        dir_input = gr.Textbox(
                            label="Directory Path",
                            placeholder="Enter path to directory containing documents"
                        )
                        dir_button = gr.Button("Process Directory")
                upload_output = gr.Textbox(label="Upload Status")
                
            # Configuration Tab
            with gr.Tab("Configuration"):
                with gr.Row():
                    chunk_size = gr.Slider(
                        minimum=64,
                        maximum=1024,
                        value=256,
                        step=32,
                        label="Chunk Size"
                    )
                    chunk_overlap = gr.Slider(
                        minimum=0,
                        maximum=256,
                        value=64,
                        step=16,
                        label="Chunk Overlap"
                    )
                with gr.Row():
                    index_type = gr.Dropdown(
                        choices=["flat", "ivf", "hnsw"],
                        value="flat",
                        label="Index Type"
                    )
                    context_strategy = gr.Dropdown(
                        choices=["concatenate", "best_match"],
                        value="concatenate",
                        label="Context Strategy"
                    )
                max_context = gr.Slider(
                    minimum=500,
                    maximum=5000,
                    value=2000,
                    step=500,
                    label="Max Context Length"
                )
                config_button = gr.Button("Update Configuration")
                config_output = gr.Textbox(label="Configuration Status")
                
            # Query Tab
            with gr.Tab("Query"):
                query_input = gr.Textbox(
                    label="Question",
                    placeholder="Enter your question here"
                )
                with gr.Row():
                    k_value = gr.Slider(
                        minimum=1,
                        maximum=10,
                        value=5,
                        step=1,
                        label="Number of Contexts (k)"
                    )
                    include_metadata = gr.Checkbox(
                        label="Include Sources",
                        value=True
                    )
                query_button = gr.Button("Submit Query")
                with gr.Row():
                    answer_output = gr.Textbox(label="Answer")
                    sources_output = gr.Textbox(label="Sources")
        
        # Event handlers
        upload_button.click(
            interface.process_file,
            inputs=[file_input],
            outputs=[upload_output]
        )
        
        dir_button.click(
            interface.process_directory,
            inputs=[dir_input],
            outputs=[upload_output]
        )
        
        config_button.click(
            interface.update_config,
            inputs=[
                chunk_size,
                chunk_overlap,
                index_type,
                context_strategy,
                max_context
            ],
            outputs=[config_output]
        )
        
        query_button.click(
            interface.query_system,
            inputs=[query_input, k_value, include_metadata],
            outputs=[answer_output, sources_output]
        )
    
    return app

if __name__ == "__main__":
    app = create_interface()
    app.launch(share=True)
