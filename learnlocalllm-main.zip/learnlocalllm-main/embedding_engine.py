import os
import numpy as np
from typing import List, Optional, Dict
from sentence_transformers import SentenceTransformer
import torch
import json
from datetime import datetime
import hashlib

class EmbeddingEngine:
    def __init__(
        self,
        model_name: str = 'all-mpnet-base-v2',
        cache_dir: Optional[str] = None,
        device: Optional[str] = None
    ):
        """
        Initialize the EmbeddingEngine with a specified model and caching options.
        
        Args:
            model_name (str): Name of the SentenceTransformer model to use
            cache_dir (Optional[str]): Directory to store embedding cache
            device (Optional[str]): Device to run the model on ('cpu', 'cuda', etc.)
        """
        self.model_name = model_name
        self.cache_dir = cache_dir
        
        # Set device
        if device is None:
            self.device = "cuda" if torch.cuda.is_available() else "cpu"
        else:
            self.device = device
            
        # Initialize the model
        self.model = SentenceTransformer(model_name, device=self.device)
        
        # Create cache directory if specified
        if cache_dir and not os.path.exists(cache_dir):
            os.makedirs(cache_dir)
            
        # Cache metadata
        self.cache_metadata = {}
        if cache_dir:
            self.metadata_path = os.path.join(cache_dir, 'embedding_metadata.json')
            self._load_cache_metadata()

    def _generate_cache_key(self, text: str) -> str:
        """
        Generate a unique cache key for a text chunk.
        
        Args:
            text (str): Text chunk to generate key for
            
        Returns:
            str: Cache key
        """
        return hashlib.sha256(text.encode()).hexdigest()

    def _load_cache_metadata(self):
        """Load cache metadata from disk if it exists."""
        if os.path.exists(self.metadata_path):
            with open(self.metadata_path, 'r') as f:
                self.cache_metadata = json.load(f)
        else:
            self.cache_metadata = {
                'model_name': self.model_name,
                'created_at': datetime.now().isoformat(),
                'embeddings': {}
            }
            self._save_cache_metadata()

    def _save_cache_metadata(self):
        """Save cache metadata to disk."""
        if self.cache_dir:
            with open(self.metadata_path, 'w') as f:
                json.dump(self.cache_metadata, f, indent=2)

    def _get_cached_embedding(self, cache_key: str) -> Optional[np.ndarray]:
        """
        Retrieve a cached embedding if it exists.
        
        Args:
            cache_key (str): Cache key for the embedding
            
        Returns:
            Optional[np.ndarray]: Cached embedding if found, None otherwise
        """
        if not self.cache_dir or cache_key not in self.cache_metadata['embeddings']:
            return None
            
        cache_file = os.path.join(self.cache_dir, f"{cache_key}.npy")
        if os.path.exists(cache_file):
            return np.load(cache_file)
        return None

    def _cache_embedding(self, cache_key: str, embedding: np.ndarray, text: str):
        """
        Cache an embedding to disk.
        
        Args:
            cache_key (str): Cache key for the embedding
            embedding (np.ndarray): Embedding to cache
            text (str): Original text for metadata
        """
        if not self.cache_dir:
            return
            
        # Save embedding
        cache_file = os.path.join(self.cache_dir, f"{cache_key}.npy")
        np.save(cache_file, embedding)
        
        # Update metadata
        self.cache_metadata['embeddings'][cache_key] = {
            'created_at': datetime.now().isoformat(),
            'text_length': len(text),
            'text_preview': text[:100] + '...' if len(text) > 100 else text
        }
        self._save_cache_metadata()

    def create_embeddings(
        self,
        texts: List[str],
        batch_size: int = 32,
        show_progress: bool = True
    ) -> np.ndarray:
        """
        Create embeddings for a list of text chunks.
        
        Args:
            texts (List[str]): List of text chunks to embed
            batch_size (int): Batch size for processing
            show_progress (bool): Whether to show progress bar
            
        Returns:
            np.ndarray: Array of embeddings
        """
        # Check cache first
        embeddings = []
        texts_to_embed = []
        cache_keys = []
        
        for text in texts:
            cache_key = self._generate_cache_key(text)
            cached_embedding = self._get_cached_embedding(cache_key)
            
            if cached_embedding is not None:
                embeddings.append(cached_embedding)
            else:
                texts_to_embed.append(text)
                cache_keys.append(cache_key)
        
        # Create embeddings for uncached texts
        if texts_to_embed:
            new_embeddings = self.model.encode(
                texts_to_embed,
                batch_size=batch_size,
                show_progress_bar=show_progress,
                convert_to_tensor=False
            )
            
            # Cache new embeddings
            for idx, (text, embedding, cache_key) in enumerate(zip(texts_to_embed, new_embeddings, cache_keys)):
                self._cache_embedding(cache_key, embedding, text)
                embeddings.append(embedding)
        
        return np.array(embeddings).astype('float32')

    def create_query_embedding(self, query: str) -> np.ndarray:
        """
        Create embedding for a single query text.
        
        Args:
            query (str): Query text to embed
            
        Returns:
            np.ndarray: Query embedding
        """
        embedding = self.model.encode(
            [query],
            convert_to_tensor=False,
            show_progress_bar=False
        )
        return embedding.astype('float32')

    def clear_cache(self):
        """Clear the embedding cache."""
        if not self.cache_dir:
            return
            
        # Remove all cached embedding files
        for cache_key in self.cache_metadata['embeddings'].keys():
            cache_file = os.path.join(self.cache_dir, f"{cache_key}.npy")
            if os.path.exists(cache_file):
                os.remove(cache_file)
        
        # Reset metadata
        self.cache_metadata['embeddings'] = {}
        self._save_cache_metadata()
