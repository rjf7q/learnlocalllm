from typing import List, Optional, Dict, Union
import numpy as np

class ResponseGenerator:
    def __init__(
        self,
        max_context_length: int = 2000,
        context_strategy: str = 'concatenate'
    ):
        """
        Initialize the ResponseGenerator.
        
        Args:
            max_context_length (int): Maximum length of context to use
            context_strategy (str): Strategy for combining multiple contexts ('concatenate' or 'best_match')
        """
        self.max_context_length = max_context_length
        self.context_strategy = context_strategy

    def _truncate_context(self, context: str) -> str:
        """
        Truncate context to maximum length while trying to maintain complete sentences.
        
        Args:
            context (str): Context to truncate
            
        Returns:
            str: Truncated context
        """
        if len(context) <= self.max_context_length:
            return context
            
        # Try to truncate at sentence boundary
        truncated = context[:self.max_context_length]
        last_period = truncated.rfind('.')
        last_question = truncated.rfind('?')
        last_exclamation = truncated.rfind('!')
        
        # Find the last sentence boundary
        last_boundary = max(last_period, last_question, last_exclamation)
        
        if last_boundary > 0:
            return context[:last_boundary + 1]
        return truncated

    def _combine_contexts(
        self,
        contexts: List[str],
        distances: Optional[np.ndarray] = None
    ) -> str:
        """
        Combine multiple context chunks into a single context.
        
        Args:
            contexts (List[str]): List of context chunks
            distances (Optional[np.ndarray]): Distances for each chunk if available
            
        Returns:
            str: Combined context
        """
        if not contexts:
            return ""
            
        if self.context_strategy == 'best_match':
            # If distances are provided, use the closest match
            if distances is not None:
                best_idx = np.argmin(distances)
                return self._truncate_context(contexts[best_idx])
            # Otherwise, use the first context
            return self._truncate_context(contexts[0])
            
        elif self.context_strategy == 'concatenate':
            # Combine all contexts with newlines
            combined = "\n".join(contexts)
            return self._truncate_context(combined)
            
        else:
            raise ValueError(f"Unsupported context strategy: {self.context_strategy}")

    def generate_response(
        self,
        query: str,
        contexts: List[str],
        distances: Optional[np.ndarray] = None,
        metadata: Optional[Dict] = None
    ) -> Dict[str, Union[str, List[str], Dict]]:
        """
        Generate a response based on the query and retrieved contexts.
        
        Args:
            query (str): User's query
            contexts (List[str]): Retrieved context chunks
            distances (Optional[np.ndarray]): Distances for each chunk if available
            metadata (Optional[Dict]): Additional metadata to include in response
            
        Returns:
            Dict[str, Union[str, List[str], Dict]]: Response containing answer and metadata
        """
        # Combine contexts
        context = self._combine_contexts(contexts, distances)
        
        # For now, simply return the context as the answer
        # This will be replaced with LLM-based response generation in the future
        response = {
            'query': query,
            'answer': context,
            'contexts': contexts,
            'strategy': self.context_strategy
        }
        
        # Add distances if available
        if distances is not None:
            response['distances'] = distances.tolist()
            
        # Add any additional metadata
        if metadata:
            response['metadata'] = metadata
            
        return response

    def format_response(
        self,
        response: Dict[str, Union[str, List[str], Dict]],
        include_metadata: bool = False
    ) -> str:
        """
        Format the response dictionary into a readable string.
        
        Args:
            response (Dict[str, Union[str, List[str], Dict]]): Response dictionary
            include_metadata (bool): Whether to include metadata in formatted output
            
        Returns:
            str: Formatted response string
        """
        formatted = []
        
        # Add query
        formatted.append(f"Query: {response['query']}\n")
        
        # Add answer
        formatted.append(f"Answer: {response['answer']}\n")
        
        if include_metadata:
            # Add context strategy
            formatted.append(f"\nContext Strategy: {response['strategy']}")
            
            # Add number of contexts used
            formatted.append(f"Number of Contexts: {len(response['contexts'])}")
            
            # Add distances if available
            if 'distances' in response:
                distances_str = [f"{d:.4f}" for d in response['distances']]
                formatted.append(f"Distances: {', '.join(distances_str)}")
                
            # Add any additional metadata
            if 'metadata' in response:
                formatted.append("\nAdditional Metadata:")
                for key, value in response['metadata'].items():
                    formatted.append(f"{key}: {value}")
                    
        return "\n".join(formatted)
