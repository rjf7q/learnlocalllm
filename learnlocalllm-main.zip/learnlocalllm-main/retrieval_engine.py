import numpy as np
import faiss
from typing import List, Tuple, Optional, Dict
import os
import json
from datetime import datetime

class RetrievalEngine:
    def __init__(
        self,
        dimension: int,
        index_type: str = 'flat',
        metric: str = 'l2',
        nlist: int = 100,
        nprobe: int = 10,
        ef_construction: int = 200,
        ef_search: int = 50,
        cache_dir: Optional[str] = None
    ):
        """
        Initialize the RetrievalEngine with specified index parameters.
        
        Args:
            dimension (int): Dimensionality of the embeddings
            index_type (str): Type of FAISS index ('flat', 'ivf', 'hnsw')
            metric (str): Distance metric to use ('l2' or 'ip' for inner product)
            nlist (int): Number of clusters for IVF index
            nprobe (int): Number of clusters to search in IVF index
            ef_construction (int): HNSW index construction parameter
            ef_search (int): HNSW index search parameter
            cache_dir (Optional[str]): Directory to store index cache
        """
        self.dimension = dimension
        self.index_type = index_type
        self.metric = metric
        self.nlist = nlist
        self.nprobe = nprobe
        self.ef_construction = ef_construction
        self.ef_search = ef_search
        self.cache_dir = cache_dir
        
        # Create cache directory if specified
        if cache_dir and not os.path.exists(cache_dir):
            os.makedirs(cache_dir)
        
        self.index = self._create_index()
        
    def _create_index(self) -> faiss.Index:
        """
        Create a FAISS index based on the specified parameters.
        
        Returns:
            faiss.Index: Created FAISS index
        """
        if self.metric == 'ip':
            metric_type = faiss.METRIC_INNER_PRODUCT
        else:
            metric_type = faiss.METRIC_L2
            
        if self.index_type == 'flat':
            if self.metric == 'ip':
                return faiss.IndexFlatIP(self.dimension)
            else:
                return faiss.IndexFlatL2(self.dimension)
                
        elif self.index_type == 'ivf':
            # Create quantizer
            quantizer = faiss.IndexFlatL2(self.dimension)
            
            # Create IVF index
            index = faiss.IndexIVFFlat(quantizer, self.dimension, self.nlist, metric_type)
            index.nprobe = self.nprobe
            
            return index
            
        elif self.index_type == 'hnsw':
            index = faiss.IndexHNSWFlat(self.dimension, 32, metric_type)
            index.hnsw.efConstruction = self.ef_construction
            index.hnsw.efSearch = self.ef_search
            
            return index
            
        else:
            raise ValueError(f"Unsupported index type: {self.index_type}")

    def add_embeddings(self, embeddings: np.ndarray):
        """
        Add embeddings to the FAISS index.
        
        Args:
            embeddings (np.ndarray): Embeddings to add to the index
        """
        if self.index_type == 'ivf' and not self.index.is_trained:
            self.index.train(embeddings)
        
        self.index.add(embeddings.astype('float32'))

    def search(
        self,
        query_embedding: np.ndarray,
        k: int = 5,
        return_distances: bool = True
    ) -> Tuple[np.ndarray, np.ndarray]:
        """
        Search for similar embeddings in the index.
        
        Args:
            query_embedding (np.ndarray): Query embedding
            k (int): Number of nearest neighbors to retrieve
            return_distances (bool): Whether to return distances
            
        Returns:
            Tuple[np.ndarray, np.ndarray]: Tuple of (distances, indices)
        """
        # Ensure query embedding is 2D
        if len(query_embedding.shape) == 1:
            query_embedding = query_embedding.reshape(1, -1)
            
        distances, indices = self.index.search(query_embedding.astype('float32'), k)
        
        if return_distances:
            return distances, indices
        return indices

    def save_index(self, filepath: str):
        """
        Save the FAISS index to disk.
        
        Args:
            filepath (str): Path to save the index
        """
        faiss.write_index(self.index, filepath)
        
        # Save metadata
        metadata = {
            'dimension': self.dimension,
            'index_type': self.index_type,
            'metric': self.metric,
            'nlist': self.nlist,
            'nprobe': self.nprobe,
            'ef_construction': self.ef_construction,
            'ef_search': self.ef_search,
            'created_at': datetime.now().isoformat(),
            'total_vectors': self.index.ntotal
        }
        
        metadata_path = filepath + '.json'
        with open(metadata_path, 'w') as f:
            json.dump(metadata, f, indent=2)

    @classmethod
    def load_index(cls, filepath: str) -> 'RetrievalEngine':
        """
        Load a FAISS index from disk.
        
        Args:
            filepath (str): Path to the saved index
            
        Returns:
            RetrievalEngine: Loaded retrieval engine
        """
        # Load metadata
        metadata_path = filepath + '.json'
        with open(metadata_path, 'r') as f:
            metadata = json.load(f)
            
        # Create retrieval engine with saved parameters
        engine = cls(
            dimension=metadata['dimension'],
            index_type=metadata['index_type'],
            metric=metadata['metric'],
            nlist=metadata['nlist'],
            nprobe=metadata['nprobe'],
            ef_construction=metadata['ef_construction'],
            ef_search=metadata['ef_search']
        )
        
        # Load the index
        engine.index = faiss.read_index(filepath)
        
        return engine

    def optimize_index_parameters(
        self,
        test_embeddings: np.ndarray,
        test_queries: np.ndarray,
        k: int = 5
    ) -> Dict:
        """
        Optimize index parameters using test data.
        
        Args:
            test_embeddings (np.ndarray): Test embeddings
            test_queries (np.ndarray): Test query embeddings
            k (int): Number of nearest neighbors
            
        Returns:
            Dict: Optimized parameters
        """
        best_params = {}
        best_recall = 0
        
        # Get ground truth using flat index
        flat_index = faiss.IndexFlatL2(self.dimension)
        flat_index.add(test_embeddings)
        _, ground_truth = flat_index.search(test_queries, k)
        
        if self.index_type == 'ivf':
            # Test different nlist values
            nlist_values = [50, 100, 200, 400, 800]
            nprobe_values = [1, 5, 10, 20, 50]
            
            for nlist in nlist_values:
                for nprobe in nprobe_values:
                    # Create test index
                    quantizer = faiss.IndexFlatL2(self.dimension)
                    index = faiss.IndexIVFFlat(quantizer, self.dimension, nlist)
                    index.nprobe = nprobe
                    
                    # Train and add vectors
                    index.train(test_embeddings)
                    index.add(test_embeddings)
                    
                    # Search
                    _, indices = index.search(test_queries, k)
                    
                    # Calculate recall
                    recall = self._calculate_recall(ground_truth, indices)
                    
                    if recall > best_recall:
                        best_recall = recall
                        best_params = {'nlist': nlist, 'nprobe': nprobe}
                        
        elif self.index_type == 'hnsw':
            # Test different ef values
            ef_values = [50, 100, 200, 400]
            
            for ef in ef_values:
                # Create test index
                index = faiss.IndexHNSWFlat(self.dimension, 32)
                index.hnsw.efConstruction = ef
                index.hnsw.efSearch = ef
                
                # Add vectors
                index.add(test_embeddings)
                
                # Search
                _, indices = index.search(test_queries, k)
                
                # Calculate recall
                recall = self._calculate_recall(ground_truth, indices)
                
                if recall > best_recall:
                    best_recall = recall
                    best_params = {'ef_construction': ef, 'ef_search': ef}
        
        return best_params

    def _calculate_recall(
        self,
        ground_truth: np.ndarray,
        results: np.ndarray
    ) -> float:
        """
        Calculate recall@k for search results.
        
        Args:
            ground_truth (np.ndarray): Ground truth indices
            results (np.ndarray): Search result indices
            
        Returns:
            float: Recall value
        """
        recall = 0
        for gt_row, res_row in zip(ground_truth, results):
            recall += len(set(gt_row) & set(res_row)) / len(gt_row)
        return recall / len(ground_truth)
