import os
from typing import List, Optional, Dict, Union
import numpy as np
from document_processor import DocumentProcessor
from embedding_engine import EmbeddingEngine
from retrieval_engine import RetrievalEngine
from response_generator import ResponseGenerator

class RAGSystem:
    def __init__(
        self,
        embedding_model: str = 'all-mpnet-base-v2',
        chunk_size: int = 256,
        chunk_overlap: int = 64,
        cache_dir: Optional[str] = None,
        index_type: str = 'flat',
        context_strategy: str = 'concatenate',
        max_context_length: int = 2000
    ):
        """
        Initialize the RAG system.
        
        Args:
            embedding_model (str): Name of the SentenceTransformer model to use
            chunk_size (int): Size of text chunks
            chunk_overlap (int): Overlap between chunks
            cache_dir (Optional[str]): Directory for caching embeddings and indices
            index_type (str): Type of FAISS index to use
            context_strategy (str): Strategy for combining contexts
            max_context_length (int): Maximum context length for response generation
        """
        self.cache_dir = cache_dir
        
        # Create cache directories
        if cache_dir:
            self.embedding_cache_dir = os.path.join(cache_dir, 'embeddings')
            self.index_cache_dir = os.path.join(cache_dir, 'indices')
            os.makedirs(self.embedding_cache_dir, exist_ok=True)
            os.makedirs(self.index_cache_dir, exist_ok=True)
        else:
            self.embedding_cache_dir = None
            self.index_cache_dir = None
        
        # Initialize components
        self.document_processor = DocumentProcessor(
            chunk_size=chunk_size,
            chunk_overlap=chunk_overlap
        )
        
        self.embedding_engine = EmbeddingEngine(
            model_name=embedding_model,
            cache_dir=self.embedding_cache_dir
        )
        
        # Get embedding dimension from the model
        self.embedding_dimension = self.embedding_engine.model.get_sentence_embedding_dimension()
        
        self.retrieval_engine = RetrievalEngine(
            dimension=self.embedding_dimension,
            index_type=index_type,
            cache_dir=self.index_cache_dir
        )
        
        self.response_generator = ResponseGenerator(
            max_context_length=max_context_length,
            context_strategy=context_strategy
        )
        
        # Store document information
        self.document_chunks = []
        self.source_files = []
        self.is_index_built = False

    def add_documents(self, directory: str):
        """
        Process and add documents from a directory to the system.
        
        Args:
            directory (str): Path to directory containing documents
        """
        # Process documents
        chunks, sources = self.document_processor.load_and_chunk_documents(directory)
        
        if not chunks:
            print(f"No valid documents found in {directory}")
            return
            
        # Create embeddings
        embeddings = self.embedding_engine.create_embeddings(chunks)
        
        # Add to index
        self.retrieval_engine.add_embeddings(embeddings)
        
        # Store document information
        self.document_chunks.extend(chunks)
        self.source_files.extend(sources)
        self.is_index_built = True
        
        print(f"Added {len(chunks)} chunks from {len(set(sources))} documents")

    def add_document(self, filepath: str):
        """
        Process and add a single document to the system.
        
        Args:
            filepath (str): Path to the document
        """
        # Process document
        chunks = self.document_processor.process_single_document(filepath)
        
        if not chunks:
            print(f"No content extracted from {filepath}")
            return
            
        # Create embeddings
        embeddings = self.embedding_engine.create_embeddings(chunks)
        
        # Add to index
        self.retrieval_engine.add_embeddings(embeddings)
        
        # Store document information
        self.document_chunks.extend(chunks)
        self.source_files.extend([os.path.basename(filepath)] * len(chunks))
        self.is_index_built = True
        
        print(f"Added {len(chunks)} chunks from {filepath}")

    def query(
        self,
        query: str,
        k: int = 5,
        include_metadata: bool = False
    ) -> Union[str, Dict]:
        """
        Query the system with a question.
        
        Args:
            query (str): Question to ask
            k (int): Number of contexts to retrieve
            include_metadata (bool): Whether to include metadata in response
            
        Returns:
            Union[str, Dict]: Formatted response string or full response dict
        """
        if not self.is_index_built:
            raise ValueError("No documents have been added to the system yet")
            
        # Create query embedding
        query_embedding = self.embedding_engine.create_query_embedding(query)
        
        # Retrieve relevant chunks
        distances, indices = self.retrieval_engine.search(
            query_embedding,
            k=k,
            return_distances=True
        )
        
        # Get corresponding chunks
        relevant_chunks = [self.document_chunks[i] for i in indices[0]]
        source_files = [self.source_files[i] for i in indices[0]]
        
        # Generate response
        metadata = {
            'source_files': source_files,
            'num_chunks': len(relevant_chunks)
        }
        
        response = self.response_generator.generate_response(
            query=query,
            contexts=relevant_chunks,
            distances=distances[0],
            metadata=metadata
        )
        
        if include_metadata:
            return response
        return self.response_generator.format_response(response)

    def save_index(self, filepath: str):
        """
        Save the FAISS index to disk.
        
        Args:
            filepath (str): Path to save the index
        """
        if not self.is_index_built:
            raise ValueError("No index to save - add documents first")
        self.retrieval_engine.save_index(filepath)

    def load_index(self, filepath: str):
        """
        Load a FAISS index from disk.
        
        Args:
            filepath (str): Path to the saved index
        """
        self.retrieval_engine = RetrievalEngine.load_index(filepath)
        self.is_index_built = True

    def optimize_retrieval(
        self,
        test_queries: List[str],
        k: int = 5
    ) -> Dict:
        """
        Optimize retrieval parameters using test queries.
        
        Args:
            test_queries (List[str]): List of test queries
            k (int): Number of contexts to retrieve
            
        Returns:
            Dict: Optimized parameters
        """
        if not self.is_index_built:
            raise ValueError("No index to optimize - add documents first")
            
        # Create embeddings for test queries
        query_embeddings = np.vstack([
            self.embedding_engine.create_query_embedding(q)
            for q in test_queries
        ])
        
        # Get all document embeddings
        doc_embeddings = self.retrieval_engine.index.reconstruct_n(0, self.retrieval_engine.index.ntotal)
        
        # Optimize parameters
        best_params = self.retrieval_engine.optimize_index_parameters(
            doc_embeddings,
            query_embeddings,
            k=k
        )
        
        return best_params
