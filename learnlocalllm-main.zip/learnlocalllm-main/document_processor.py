import os
import pdfplumber
from docx import Document
from typing import List, Optional, Tuple

class DocumentProcessor:
    def __init__(self, chunk_size: int = 256, chunk_overlap: int = 64):
        """
        Initialize the DocumentProcessor with chunk size and overlap parameters.
        
        Args:
            chunk_size (int): The size of each text chunk
            chunk_overlap (int): The number of characters to overlap between chunks
        """
        self.chunk_size = chunk_size
        self.chunk_overlap = chunk_overlap

    def extract_text_from_pdf(self, pdf_path: str) -> str:
        """
        Extract text content from a PDF file.
        
        Args:
            pdf_path (str): Path to the PDF file
            
        Returns:
            str: Extracted text from the PDF
        """
        try:
            with pdfplumber.open(pdf_path) as pdf:
                text = ""
                for page in pdf.pages:
                    extracted_text = page.extract_text()
                    if extracted_text:
                        text += extracted_text + "\n"
            return text.strip()
        except Exception as e:
            raise Exception(f"Error extracting text from PDF {pdf_path}: {str(e)}")

    def extract_text_from_docx(self, docx_path: str) -> str:
        """
        Extract text content from a DOCX file.
        
        Args:
            docx_path (str): Path to the DOCX file
            
        Returns:
            str: Extracted text from the DOCX
        """
        try:
            doc = Document(docx_path)
            text = ""
            for para in doc.paragraphs:
                if para.text:
                    text += para.text + "\n"
            return text.strip()
        except Exception as e:
            raise Exception(f"Error extracting text from DOCX {docx_path}: {str(e)}")

    def create_chunks(self, text: str) -> List[str]:
        """
        Split text into overlapping chunks of specified size.
        
        Args:
            text (str): Text to be chunked
            
        Returns:
            List[str]: List of text chunks
        """
        chunks = []
        if not text:
            return chunks
            
        start = 0
        text_length = len(text)
        
        while start < text_length:
            end = start + self.chunk_size
            
            # Adjust chunk end to not split words
            if end < text_length:
                # Look for the last space within the chunk
                while end > start and text[end-1] != ' ':
                    end -= 1
                if end == start:  # If no space found, force split at chunk_size
                    end = start + self.chunk_size
            
            # Add the chunk
            chunk = text[start:end].strip()
            if chunk:  # Only add non-empty chunks
                chunks.append(chunk)
            
            # Move start position for next chunk, considering overlap
            start = end - self.chunk_overlap
            
            # Ensure we don't get stuck in an infinite loop
            if start >= text_length:
                break
            
        return chunks

    def load_and_chunk_documents(self, directory: str) -> Tuple[List[str], List[str]]:
        """
        Load all PDF and DOCX documents from a directory and split them into chunks.
        
        Args:
            directory (str): Path to the directory containing documents
            
        Returns:
            Tuple[List[str], List[str]]: Tuple containing (document_chunks, source_files)
                where source_files tracks which file each chunk came from
        """
        document_chunks = []
        source_files = []
        
        try:
            for filename in os.listdir(directory):
                filepath = os.path.join(directory, filename)
                
                if filename.lower().endswith('.pdf'):
                    text = self.extract_text_from_pdf(filepath)
                elif filename.lower().endswith('.docx'):
                    text = self.extract_text_from_docx(filepath)
                else:
                    continue
                
                chunks = self.create_chunks(text)
                document_chunks.extend(chunks)
                source_files.extend([filename] * len(chunks))
                
            return document_chunks, source_files
            
        except Exception as e:
            raise Exception(f"Error processing documents in {directory}: {str(e)}")

    def process_single_document(self, filepath: str) -> List[str]:
        """
        Process a single document and return its chunks.
        
        Args:
            filepath (str): Path to the document
            
        Returns:
            List[str]: List of text chunks from the document
        """
        try:
            if filepath.lower().endswith('.pdf'):
                text = self.extract_text_from_pdf(filepath)
            elif filepath.lower().endswith('.docx'):
                text = self.extract_text_from_docx(filepath)
            else:
                raise ValueError(f"Unsupported file format: {filepath}")
                
            return self.create_chunks(text)
            
        except Exception as e:
            raise Exception(f"Error processing document {filepath}: {str(e)}")
